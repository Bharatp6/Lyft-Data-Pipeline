import random 
import pytz
from datetime import datetime

def get_clean_data_from_dict(df,keys_to_exclude):
  kes = [list(df[i].keys()) for i in range(len(df))]
  merged_set = set(j for i in kes for j in i)
  dict_cols=list(merged_set-set(keys_to_exclude))
  non_dict_cols=keys_to_exclude
  filtered_data=[]

  # for keys in merged_set:
  #   samp_df = (df[len(df)//(random.randint(1, len(df)))])
  #   if isinstance(samp_df[keys],str) or isinstance(samp_df[keys],int) or isinstance(samp_df[keys],float):
  #     dict_cols.append(keys)
  #   else:
  #     continue
  #non_dict_columns = list(merged_set-set(dict_cols)) ## check if more attributes have come

  # if len(non_dict_columns)==1 and non_dict_columns[0]=='vehicle_types_available':
  # keys_to_exclude = non_dict_columns
  filtered_data=[{k: v for k, v in row.items() if k != keys_to_exclude} for row in df]

  return dict_cols,non_dict_cols,filtered_data


def get_nested_dtypes(df):
    vtypes = []
    for i in df:
        vtypes.append({f"vehicle_type_id_{j['vehicle_type_id']}": j['count'] for j in i['vehicle_types_available']})
    return vtypes 


def convert_timezone(original_datetime_str):
  original_timezone = pytz.timezone('GMT')

  # Target timezone: Eastern Standard Time (EST)
  target_timezone = pytz.timezone('US/Eastern')

  # Convert the original datetime string to a datetime object
  original_datetime = datetime.strptime(original_datetime_str, '%Y-%m-%d %H:%M:%S')

  # Localize the original datetime to the original timezone
  localized_datetime = original_timezone.localize(original_datetime)

  # Convert to the target timezone
  target_datetime = localized_datetime.astimezone(target_timezone)

  # Convert to "YY-MM-DD HH:MM:SS" format
  formatted_datetime = target_datetime.strftime('%y-%m-%d %H:%M:%S')

  return formatted_datetime



# Assuming this is your timezone conversion function from earlier
def convert_timezone(dt, from_tz="UTC", to_tz="America/New_York"):
    from_zone = pytz.timezone(from_tz)
    to_zone = pytz.timezone(to_tz)

    utc = from_zone.localize(dt)
    target_time = utc.astimezone(to_zone)
    return target_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]  # Trimming microseconds to milliseconds if needed


# Simple function to convert '1' to True and '0' to False
def convert_to_bool(value):
    return True if value == 1 else False
