from google.cloud import bigquery
import json
import base64
from helper_functions import * # Ensure this is correctly defined
from datetime import datetime

def pull_station_status(data, context):
    # Initialize the BigQuery client
    bigquery_client = bigquery.Client()

    # Specify your BigQuery dataset and table name
    table_id = 'future-mystery-418617.Station_status.STATION_STATUS_NRT'

    # Decode the message data
    payload = base64.b64decode(data['data']).decode("utf-8")
    #message_type = data['attributes']['message_type']
    df = json.loads(payload)

    #if message_type == "station_stat":
    ordered_data = []
    data_with_date = []
    
    ### Transformation 1: Unnest the nested structure
    dict_cols, non_dict_columns, filtered_data = get_clean_data_from_dict(df,"vehicle_types_available")
    vtypes = get_nested_dtypes(df)
    combined_list = [{**dict1, **dict2} for dict1, dict2 in zip(filtered_data, vtypes)]

    ### Transformation 2: Convert the GMT timezone datetime to EST timezone
    for record in combined_list:
        # Convert and update datetime
        dt = datetime.fromtimestamp(record['last_reported'])
        record["datetime"] = convert_timezone(dt)

        # Convert boolean fields
        record["is_returning"] = convert_to_bool(record.get("is_returning", 0))
        record["is_renting"] = convert_to_bool(record.get("is_renting", 0))
        record["is_installed"] = convert_to_bool(record.get("is_installed", 0))

        # Add the updated record to your list
        data_with_date.append(record)

    ### Transformation 3: Order the dictionary according to the BigQuery schema
    ordered_list = ['datetime', 'station_id', 'num_bikes_available', 'vehicle_type_id_1', 'vehicle_type_id_2', 'num_ebikes_available', 'num_docks_available', 'num_docks_disabled', 'num_bikes_disabled', 'num_scooters_available', 'num_scooters_unavailable', 'is_installed', 'is_renting', 'is_returning', 'last_reported']
    for unordered_dict in data_with_date:
        ordered_data.append({key: unordered_dict.get(key, None) for key in ordered_list if key in unordered_dict})

    print(str(len(ordered_data)))
    errors = bigquery_client.insert_rows_json(table_id, ordered_data)

    if errors == []:
        print("New rows have been added.")
        return "Success", 200
    else:
        print("Encountered errors while inserting rows:", errors)
        return "Error", 500
    
    #elif message_type == "free_bike_stat":
        
