from google.cloud import pubsub_v1,bigquery
import json
from helper_functions import *  # Make sure this is correctly defined
import pytz
from datetime import datetime

def pull_station_status(data, context):
    # Initialize Publisher and Subscriber clients
    subscriber = pubsub_v1.SubscriberClient()
    #publisher = pubsub_v1.PublisherClient()

    # Initialize the BigQuery client
    bigquery_client = bigquery.Client()

    # Specify your BigQuery dataset and table name
    table_id = 'future-mystery-418617.Station_status.STATION_STATUS_NRT'

    # Google Cloud project ID
    project_id = "future-mystery-418617"
    # Pub/Sub subscription and target topic names
    subscription_name = "Station_status_stream-sub"
    #target_topic_name = "station_status_bigquery"  # Shortened for topic_path method

    # Construct paths
    subscription_path = subscriber.subscription_path(project_id, subscription_name)
    #target_topic_path = publisher.topic_path(project_id, target_topic_name)

    def callback(message):
        # Decode message
        data_json = message.data.decode("utf-8")
        df = json.loads(data_json)

        ordered_data = []
        data_with_date = []
        

        ### Transformation 1 =====> Unnest the nested structure of 
        dict_cols, non_dict_columns, filtered_data = get_clean_data_from_dict(df)
        vtypes = get_nested_dtypes(df)
        combined_list = [{**dict1, **dict2} for dict1, dict2 in zip(filtered_data, vtypes)]


        ### Transformation 2 ======> Convert the GMT timezone datetime to EST timezone  
        # Assuming 'combined_list' is your list of records
        for record in combined_list:
            # Convert and update datetime
            dt = datetime.fromtimestamp(record['last_reported'])
            record["datetime"] = convert_timezone(dt)

            # Convert boolean fields
            record["is_returning"] = convert_to_bool(record.get("is_returning", 0))
            record["is_renting"] = convert_to_bool(record.get("is_renting", 0))
            record["is_installed"] = convert_to_bool(record.get("is_installed", 0))

            # Add the updated record to your list
            data_with_date.append(record)


        ### Transformation 3 ======> Order the dictionary according to the schema in the bigquery 
        ordered_list = ['datetime', 'station_id', 'num_bikes_available', 'vehicle_type_id_1', 'vehicle_type_id_2', 'num_ebikes_available', 'num_docks_available', 'num_docks_disabled', 'num_bikes_disabled', 'num_scooters_available', 'num_scooters_unavailable', 'is_installed', 'is_renting', 'is_returning','last_reported']

        for unordered_dict in data_with_date:
            ordered_data.append({key: unordered_dict.get(key, None) for key in ordered_list if key in unordered_dict})

        print(ordered_data)
        errors = bigquery_client.insert_rows_json(table_id, ordered_data)

        if errors == []:
          print("New rows have been added.")
        else:
          print("Encountered errors while inserting rows: {}".format(errors))


        # Publish the ordered data as a single message
        #data_str = json.dumps(ordered_data)  # Convert the list of dicts to a JSON string
        #publisher.publish(
        #    topic=target_topic_path,
        #    data=data_str.encode('utf-8')  # Data must be a bytestring
        #)

        #print("Published data to topic:", target_topic_path)
        message.ack()

    # Subscribe and wait for messages
    subscriber.subscribe(subscription_path, callback=callback)

    return 'success'
